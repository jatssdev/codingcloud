let mongoose = require('mongoose')

mongoose.connect('mongodb://127.0.0.1:27017/codingcloud').then(() => {
    console.log('database connected successfully')
})